export type Category = 'نافلز' | 'گاز نجیب' | 'فلز قلیایی' | 'فلز قلیایی خاکی' | 'شبه‌فلز' | 'هالوژن' | 'فلز پس‌واسطه' | 'فلز واسطه';

export interface ElementData {
  Atomic_Number: number;
  Symbol: string;
  Name: string;
  Mass: number;
  Electronegativity: number | null;
  Melting_Point: number;
  Boiling_Point: number;
  Electron_Configuration: string;
  Group: number;
  Period: number;
  Category: Category;
}

// Educational reference values: masses in u, phase-change temperatures in °C.
// Each entry is independent of the visual grid layout in tableLayout.ts.
export const ELEMENTS: ElementData[] = [
  [1,'H','هیدروژن',1.008,2.20,-259.16,-252.87,'1s¹',1,1,'نافلز'],
  [2,'He','هلیم',4.0026,null,-272.2,-268.93,'1s²',18,1,'گاز نجیب'],
  [3,'Li','لیتیم',6.94,0.98,180.54,1342,'[He] 2s¹',1,2,'فلز قلیایی'],
  [4,'Be','بریلیم',9.0122,1.57,1287,2469,'[He] 2s²',2,2,'فلز قلیایی خاکی'],
  [5,'B','بور',10.81,2.04,2076,3927,'[He] 2s² 2p¹',13,2,'شبه‌فلز'],
  [6,'C','کربن',12.011,2.55,3550,4827,'[He] 2s² 2p²',14,2,'نافلز'],
  [7,'N','نیتروژن',14.007,3.04,-210.0,-195.79,'[He] 2s² 2p³',15,2,'نافلز'],
  [8,'O','اکسیژن',15.999,3.44,-218.79,-182.95,'[He] 2s² 2p⁴',16,2,'نافلز'],
  [9,'F','فلوئور',18.998,3.98,-219.67,-188.11,'[He] 2s² 2p⁵',17,2,'هالوژن'],
  [10,'Ne','نئون',20.180,null,-248.59,-246.046,'[He] 2s² 2p⁶',18,2,'گاز نجیب'],
  [11,'Na','سدیم',22.990,0.93,97.79,882.94,'[Ne] 3s¹',1,3,'فلز قلیایی'],
  [12,'Mg','منیزیم',24.305,1.31,650,1090,'[Ne] 3s²',2,3,'فلز قلیایی خاکی'],
  [13,'Al','آلومینیوم',26.982,1.61,660.32,2519,'[Ne] 3s² 3p¹',13,3,'فلز پس‌واسطه'],
  [14,'Si','سیلیسیم',28.085,1.90,1414,3265,'[Ne] 3s² 3p²',14,3,'شبه‌فلز'],
  [15,'P','فسفر',30.974,2.19,44.15,280.5,'[Ne] 3s² 3p³',15,3,'نافلز'],
  [16,'S','گوگرد',32.06,2.58,115.21,444.6,'[Ne] 3s² 3p⁴',16,3,'نافلز'],
  [17,'Cl','کلر',35.45,3.16,-101.5,-34.04,'[Ne] 3s² 3p⁵',17,3,'هالوژن'],
  [18,'Ar','آرگون',39.948,null,-189.34,-185.85,'[Ne] 3s² 3p⁶',18,3,'گاز نجیب'],
  [19,'K','پتاسیم',39.098,0.82,63.5,759,'[Ar] 4s¹',1,4,'فلز قلیایی'],
  [20,'Ca','کلسیم',40.078,1.00,842,1484,'[Ar] 4s²',2,4,'فلز قلیایی خاکی'],
  [21,'Sc','اسکاندیم',44.956,1.36,1541,2836,'[Ar] 3d¹ 4s²',3,4,'فلز واسطه'],
  [22,'Ti','تیتانیم',47.867,1.54,1668,3287,'[Ar] 3d² 4s²',4,4,'فلز واسطه'],
  [23,'V','وانادیم',50.942,1.63,1910,3407,'[Ar] 3d³ 4s²',5,4,'فلز واسطه'],
  [24,'Cr','کروم',51.996,1.66,1907,2671,'[Ar] 3d⁵ 4s¹',6,4,'فلز واسطه'],
  [25,'Mn','منگنز',54.938,1.55,1246,2061,'[Ar] 3d⁵ 4s²',7,4,'فلز واسطه'],
  [26,'Fe','آهن',55.845,1.83,1538,2862,'[Ar] 3d⁶ 4s²',8,4,'فلز واسطه'],
  [27,'Co','کبالت',58.933,1.88,1495,2927,'[Ar] 3d⁷ 4s²',9,4,'فلز واسطه'],
  [28,'Ni','نیکل',58.693,1.91,1455,2913,'[Ar] 3d⁸ 4s²',10,4,'فلز واسطه'],
  [29,'Cu','مس',63.546,1.90,1084.62,2562,'[Ar] 3d¹⁰ 4s¹',11,4,'فلز واسطه'],
  [30,'Zn','روی',65.38,1.65,419.53,907,'[Ar] 3d¹⁰ 4s²',12,4,'فلز واسطه'],
  [31,'Ga','گالیم',69.723,1.81,29.76,2204,'[Ar] 3d¹⁰ 4s² 4p¹',13,4,'فلز پس‌واسطه'],
  [32,'Ge','ژرمانیم',72.630,2.01,938.25,2833,'[Ar] 3d¹⁰ 4s² 4p²',14,4,'شبه‌فلز'],
  [33,'As','آرسنیک',74.922,2.18,817,614,'[Ar] 3d¹⁰ 4s² 4p³',15,4,'شبه‌فلز'],
  [34,'Se','سلنیم',78.971,2.55,221,685,'[Ar] 3d¹⁰ 4s² 4p⁴',16,4,'نافلز'],
  [35,'Br','برم',79.904,2.96,-7.2,58.8,'[Ar] 3d¹⁰ 4s² 4p⁵',17,4,'هالوژن'],
  [36,'Kr','کریپتون',83.798,3.00,-157.36,-153.22,'[Ar] 3d¹⁰ 4s² 4p⁶',18,4,'گاز نجیب'],
].map(([Atomic_Number, Symbol, Name, Mass, Electronegativity, Melting_Point, Boiling_Point, Electron_Configuration, Group, Period, Category]) => ({
  Atomic_Number: Atomic_Number as number, Symbol: Symbol as string, Name: Name as string, Mass: Mass as number,
  Electronegativity: Electronegativity as number | null, Melting_Point: Melting_Point as number,
  Boiling_Point: Boiling_Point as number, Electron_Configuration: Electron_Configuration as string,
  Group: Group as number, Period: Period as number, Category: Category as Category,
}));

export const ELEMENT_BY_NUMBER = new Map(ELEMENTS.map(element => [element.Atomic_Number, element]));

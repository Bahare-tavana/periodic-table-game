import { ELEMENTS, type ElementData } from './elements';

export type Mode = 'duel' | 'truth' | 'identify' | 'quiz';
export type Question = {
  id: string;
  mode: Mode;
  prompt: string;
  correct: string;
  options: string[];
  element: ElementData;
  detail: string;
  hint: string;
  focus?: ElementData[];
};

const pick = <T,>(items: T[]): T => items[Math.floor(Math.random() * items.length)];
const shuffled = <T,>(items: T[]): T[] => [...items].sort(() => Math.random() - 0.5);
const sample = <T,>(items: T[], count: number): T[] => shuffled(items).slice(0, count);
const fmt = (value: number) => new Intl.NumberFormat('fa-IR', { maximumFractionDigits: 2 }).format(value);

export function makeQuestion(mode: Mode, previousId?: string): Question {
  let question: Question;
  let tries = 0;
  do {
    const element = pick(ELEMENTS);
    const id = `${mode}-${element.Atomic_Number}-${Math.random().toString(36).slice(2, 8)}`;
    if (mode === 'duel') {
      const property = pick([
        { key: 'Electronegativity', label: 'الکترونگاتیوی', suffix: '' },
        { key: 'Melting_Point', label: 'نقطهٔ ذوب', suffix: ' درجهٔ سانتی‌گراد' },
        { key: 'Boiling_Point', label: 'نقطهٔ جوش', suffix: ' درجهٔ سانتی‌گراد' },
        { key: 'Mass', label: 'جرم اتمی', suffix: ' واحد جرم اتمی' },
        { key: 'Atomic_Number', label: 'عدد اتمی', suffix: '' },
      ] as const);
      const eligible = ELEMENTS.filter(e => e[property.key] !== null);
      const a = pick(eligible);
      const b = pick(eligible.filter(e => e.Atomic_Number !== a.Atomic_Number && e[property.key] !== a[property.key]));
      const av = a[property.key] as number;
      const bv = b[property.key] as number;
      question = {
        id: `${mode}-${a.Atomic_Number}-${b.Atomic_Number}-${property.key}`, mode,
        prompt: `کدام عنصر ${property.label} بالاتری دارد؟`,
        correct: (av >= bv ? a : b).Name, options: [a.Name, b.Name],
        element: av >= bv ? a : b, focus: [a, b],
        detail: `${a.Name}: ${fmt(av)}${property.suffix}  ·  ${b.Name}: ${fmt(bv)}${property.suffix}`,
        hint: `نماد پاسخ با «${(av >= bv ? a : b).Symbol[0]}» آغاز می‌شود.`,
      };
    } else if (mode === 'truth') {
      const truth = Math.random() < 0.5;
      const statement = pick(['group', 'period', 'category', 'number', 'symbol', 'mass'] as const);
      let text = '';
      let detail = '';
      if (statement === 'group') {
        const value = truth ? element.Group : pick(Array.from({ length: 18 }, (_, i) => i + 1).filter(n => n !== element.Group));
        text = `${element.Name} در گروه ${fmt(value)} جدول تناوبی قرار دارد.`;
        detail = `${element.Name} در گروه ${fmt(element.Group)} قرار دارد.`;
      } else if (statement === 'period') {
        const value = truth ? element.Period : pick([1,2,3,4].filter(n => n !== element.Period));
        text = `${element.Name} متعلق به دورهٔ ${fmt(value)} است.`;
        detail = `${element.Name} در دورهٔ ${fmt(element.Period)} قرار دارد.`;
      } else if (statement === 'category') {
        const value = truth ? element.Category : pick([...new Set(ELEMENTS.map(e => e.Category))].filter(c => c !== element.Category));
        text = `${element.Name} یک «${value}» است.`;
        detail = `دسته‌بندی درست ${element.Name}: ${element.Category}.`;
      } else if (statement === 'number') {
        const value = truth ? element.Atomic_Number : pick(ELEMENTS.filter(e => e.Atomic_Number !== element.Atomic_Number)).Atomic_Number;
        text = `عدد اتمی ${element.Name} برابر با ${fmt(value)} است.`;
        detail = `عدد اتمی درست ${element.Name}، ${fmt(element.Atomic_Number)} است.`;
      } else if (statement === 'symbol') {
        const value = truth ? element.Symbol : pick(ELEMENTS.filter(e => e.Symbol !== element.Symbol)).Symbol;
        text = `نماد شیمیایی ${element.Name}، ${value} است.`;
        detail = `نماد درست ${element.Name}، ${element.Symbol} است.`;
      } else {
        const value = truth ? element.Mass : pick(ELEMENTS.filter(e => e.Atomic_Number !== element.Atomic_Number)).Mass;
        text = `جرم اتمی ${element.Name} حدود ${fmt(value)} است.`;
        detail = `جرم اتمی ${element.Name} حدود ${fmt(element.Mass)} است.`;
      }
      question = { id, mode, prompt: text, correct: truth ? 'درست' : 'نادرست', options: ['درست', 'نادرست'], element, detail, hint: `عنصر مورد سؤال در دستهٔ ${element.Category} قرار دارد.` };
    } else if (mode === 'identify') {
      const property = pick(['symbol', 'atomic', 'config'] as const);
      const prompt = property === 'symbol' ? `عنصری با نماد «${element.Symbol}» و عدد اتمی ${fmt(element.Atomic_Number)} چه نام دارد؟` : property === 'atomic' ? `عنصر شمارهٔ ${fmt(element.Atomic_Number)} از گروه ${fmt(element.Group)} و دورهٔ ${fmt(element.Period)} چه نام دارد؟` : `عنصری با آرایش الکترونی «${element.Electron_Configuration}» و عدد اتمی ${fmt(element.Atomic_Number)} چه نام دارد؟`;
      question = { id, mode, prompt, correct: element.Name, options: [], element, detail: `پاسخ: ${element.Name} (${element.Symbol})، عدد اتمی ${fmt(element.Atomic_Number)}.`, hint: `نام این عنصر با «${element.Name[0]}» شروع می‌شود و ${fmt(element.Name.length)} حرف دارد.` };
    } else {
      const property = pick(['symbol', 'group', 'category', 'config', 'melting'] as const);
      const choices = sample(ELEMENTS.filter(e => e.Atomic_Number !== element.Atomic_Number && (property !== 'category' || e.Category !== element.Category) && (property !== 'group' || e.Group !== element.Group)), 3);
      let prompt = '';
      let correct = '';
      let options: string[] = [];
      if (property === 'symbol') {
        prompt = `نماد شیمیایی ${element.Name} چیست؟`;
        correct = element.Symbol; options = [correct, ...choices.map(e => e.Symbol)];
      } else if (property === 'group') {
        prompt = `${element.Name} در کدام گروه جدول تناوبی قرار دارد؟`;
        correct = `گروه ${fmt(element.Group)}`; options = [correct, ...sample([...new Set(ELEMENTS.map(e => e.Group))].filter(n => n !== element.Group), 3).map(n => `گروه ${fmt(n)}`)];
      } else if (property === 'category') {
        prompt = `${element.Name} در کدام دستهٔ عناصر قرار می‌گیرد؟`;
        correct = element.Category; options = [correct, ...sample([...new Set(ELEMENTS.map(e => e.Category))].filter(c => c !== element.Category), 3)];
      } else if (property === 'config') {
        prompt = `کدام آرایش الکترونی به ${element.Name} تعلق دارد؟`;
        correct = element.Electron_Configuration; options = [correct, ...choices.map(e => e.Electron_Configuration)];
      } else {
        prompt = `نقطهٔ ذوب ${element.Name} تقریباً چند درجهٔ سانتی‌گراد است؟`;
        correct = `${fmt(element.Melting_Point)} درجه`; options = [correct, ...choices.map(e => `${fmt(e.Melting_Point)} درجه`)];
      }
      question = { id, mode, prompt, correct, options: shuffled(options), element, detail: `پاسخ درست «${correct}» است. ${element.Name} در گروه ${fmt(element.Group)} و دورهٔ ${fmt(element.Period)} قرار دارد.`, hint: `عنصر ${element.Name} در دستهٔ ${element.Category} است.` };
    }
    tries++;
  } while (question.id === previousId && tries < 10);
  return question;
}

export const RANKS = [
  { label: 'کیمیاگر تازه‌کار', min: 0 },
  { label: 'تکنسین آزمایشگاه', min: 200 },
  { label: 'پژوهشگر', min: 600 },
  { label: 'استاد عناصر', min: 1400 },
  { label: 'افسانه‌ی کوانتومی', min: 3000 },
];

export const MODE_NAMES: Record<Mode, string> = { duel: 'دوئل عناصر', truth: 'درست یا نادرست', identify: 'عنصرشناس', quiz: 'آزمون بزرگ' };
export const MODE_DESCRIPTIONS: Record<Mode, string> = {
  duel: 'دو عنصر، یک ویژگی؛ برنده را پیدا کن.',
  truth: 'در کسری از زمان، حقیقت را از خطا جدا کن.',
  identify: 'نشانه‌ها را بخوان و نام عنصر را بنویس.',
  quiz: 'دانشت را با چهار گزینه به چالش بکش.',
};

export const TABLE_POSITIONS: { number: number; column: number; row: number }[] = [
  [1,1,1],[2,18,1],
  [3,1,2],[4,2,2],[5,13,2],[6,14,2],[7,15,2],[8,16,2],[9,17,2],[10,18,2],
  [11,1,3],[12,2,3],[13,13,3],[14,14,3],[15,15,3],[16,16,3],[17,17,3],[18,18,3],
  ...Array.from({length:18},(_,i)=>[i+19,i+1,4]),
].map(([number,column,row])=>({number,column,row}));

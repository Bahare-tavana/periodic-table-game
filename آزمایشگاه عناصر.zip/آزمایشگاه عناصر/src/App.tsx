import { useEffect, useRef, useState } from 'react';
import { Atom, BookOpen, Check, ChevronLeft, ChevronRight, CircleHelp, Clock3, Flame, FlaskConical, Grid2X2, Info, Lightbulb, Maximize2, Microscope, RotateCcw, ScanSearch, ShieldCheck, Sparkles, Trophy, Volume2, VolumeX, X, Zap } from 'lucide-react';
import { ELEMENTS, ELEMENT_BY_NUMBER, type Category, type ElementData } from './elements';
import { makeQuestion, MODE_DESCRIPTIONS, MODE_NAMES, RANKS, TABLE_POSITIONS, type Mode, type Question } from './game';
import './index.css';

type Page = 'home' | 'table' | 'guide';
type Tool = 'microscope' | 'time' | 'scanner';
type Progress = { xp: number; total: number; correct: number; bestStreak: number; streak: number; tools: Record<Tool, number> };
const DEFAULT_PROGRESS: Progress = { xp: 0, total: 0, correct: 0, bestStreak: 0, streak: 0, tools: { microscope: 1, time: 1, scanner: 1 } };
const palette: Record<Category, string> = {
  'گاز نجیب': '#40d9f0', 'فلز قلیایی': '#ffaf66', 'فلز قلیایی خاکی': '#f8c76e',
  'نافلز': '#87dfae', 'شبه‌فلز': '#b8a1fa', 'هالوژن': '#f495c5',
  'فلز پس‌واسطه': '#8faddd', 'فلز واسطه': '#7ebbf7',
};
const modeIcons = { duel: Zap, truth: ShieldCheck, identify: ScanSearch, quiz: Grid2X2 };
const format = (n: number) => new Intl.NumberFormat('fa-IR', { maximumFractionDigits: 2 }).format(n);
const normalize = (s: string) => s.trim().replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/\s+/g, ' ').replace(/[‌ٔ]/g, '').replace(/آ/g, 'ا');

function getSavedProgress(): Progress {
  try {
    const saved = JSON.parse(localStorage.getItem('element-lab-progress') || 'null');
    if (saved && typeof saved.xp === 'number') return { ...DEFAULT_PROGRESS, ...saved, tools: { ...DEFAULT_PROGRESS.tools, ...saved.tools } };
  } catch { /* Ignore damaged local data. */ }
  return DEFAULT_PROGRESS;
}
function playTone(correct: boolean, enabled: boolean) {
  if (!enabled) return;
  try {
    const Context = window.AudioContext;
    if (!Context) return;
    const context = new Context();
    const notes = correct ? [660, 880, 1100] : [220, 165];
    notes.forEach((frequency, i) => {
      const oscillator = context.createOscillator(); const gain = context.createGain();
      oscillator.type = correct ? 'sine' : 'triangle'; oscillator.frequency.value = frequency;
      gain.gain.setValueAtTime(0.0001, context.currentTime + i * 0.09);
      gain.gain.exponentialRampToValueAtTime(0.095, context.currentTime + i * 0.09 + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + i * 0.09 + 0.2);
      oscillator.connect(gain).connect(context.destination);
      oscillator.start(context.currentTime + i * 0.09); oscillator.stop(context.currentTime + i * 0.09 + 0.21);
    });
    window.setTimeout(() => void context.close(), 800);
  } catch { /* Sound is optional. */ }
}

function App() {
  const [page, setPage] = useState<Page>('home');
  const [mode, setMode] = useState<Mode | null>(null);
  const [question, setQuestion] = useState<Question | null>(null);
  const [progress, setProgress] = useState<Progress>(getSavedProgress);
  const [selected, setSelected] = useState<ElementData | null>(null);
  const [answer, setAnswer] = useState('');
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);
  const [seconds, setSeconds] = useState(25);
  const [hiddenOptions, setHiddenOptions] = useState<string[]>([]);
  const [hint, setHint] = useState(false);
  const [sound, setSound] = useState(() => localStorage.getItem('element-lab-sound') !== 'off');
  const [lastPoints, setLastPoints] = useState(0);
  const lastCorrectAt = useRef(0);
  const questionRef = useRef<HTMLDivElement>(null);

  useEffect(() => { localStorage.setItem('element-lab-progress', JSON.stringify(progress)); }, [progress]);
  useEffect(() => { localStorage.setItem('element-lab-sound', sound ? 'on' : 'off'); }, [sound]);
  useEffect(() => {
    if (!question || feedback) return;
    const timer = window.setInterval(() => setSeconds(s => Math.max(0, s - 1)), 1000);
    return () => window.clearInterval(timer);
  }, [question, feedback]);
  useEffect(() => { if (seconds === 0 && question && !feedback) submitAnswer(''); }, [seconds, question, feedback]);

  const currentRankIndex = RANKS.reduce((index, rank, i) => progress.xp >= rank.min ? i : index, 0);
  const rank = RANKS[currentRankIndex];
  const nextRank = RANKS[currentRankIndex + 1];
  const rankPercent = nextRank ? Math.min(100, Math.round((progress.xp - rank.min) / (nextRank.min - rank.min) * 100)) : 100;
  const multiplier = progress.streak >= 8 ? 5 : progress.streak >= 5 ? 3 : progress.streak >= 3 ? 2 : 1;
  const accent = palette[(question?.element || selected || ELEMENTS[1]).Category];

  function startMode(next: Mode) {
    setMode(next); setPage('home'); setSelected(null); setQuestion(makeQuestion(next));
    setFeedback(null); setSeconds(25); setAnswer(''); setHiddenOptions([]); setHint(false);
    window.setTimeout(() => questionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
  }
  function nextQuestion() {
    if (!mode) return;
    setQuestion(makeQuestion(mode, question?.id)); setFeedback(null); setSeconds(25);
    setAnswer(''); setHiddenOptions([]); setHint(false);
  }
  function exitGame() { setMode(null); setQuestion(null); setFeedback(null); setPage('home'); }
  function navigate(to: Page) { exitGame(); setPage(to); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  function submitAnswer(value: string) {
    if (!question || feedback) return;
    const correct = normalize(value) === normalize(question.correct);
    const now = Date.now();
    if (correct) {
      const rapid = now - lastCorrectAt.current <= 12000;
      const streak = rapid ? progress.streak + 1 : 1;
      const multi = streak >= 8 ? 5 : streak >= 5 ? 3 : streak >= 3 ? 2 : 1;
      const points = 20 * multi;
      const newCorrect = progress.correct + 1;
      setLastPoints(points);
      setProgress(p => ({ ...p, xp: p.xp + points, total: p.total + 1, correct: newCorrect, streak, bestStreak: Math.max(p.bestStreak, streak), tools: newCorrect % 5 === 0 ? { ...p.tools, [(['microscope', 'time', 'scanner'] as Tool[])[Math.floor(newCorrect / 5 - 1) % 3]]: p.tools[(['microscope', 'time', 'scanner'] as Tool[])[Math.floor(newCorrect / 5 - 1) % 3]] + 1 } : p.tools }));
      lastCorrectAt.current = now;
    } else {
      setLastPoints(0); lastCorrectAt.current = 0;
      setProgress(p => ({ ...p, total: p.total + 1, streak: 0 }));
    }
    setFeedback(correct ? 'correct' : 'wrong'); playTone(correct, sound);
  }
  function useTool(tool: Tool) {
    if (!question || feedback || progress.tools[tool] <= 0) return;
    if (tool === 'microscope' && (question.mode !== 'quiz' || hiddenOptions.length)) return;
    if (tool === 'scanner' && hint) return;
    setProgress(p => ({ ...p, tools: { ...p.tools, [tool]: p.tools[tool] - 1 } }));
    if (tool === 'time') setSeconds(s => s + 10);
    if (tool === 'scanner') setHint(true);
    if (tool === 'microscope') setHiddenOptions(question.options.filter(option => option !== question.correct).slice(0, 2));
  }

  return (
    <div className="app-shell" dir="rtl" style={{ '--accent': accent } as React.CSSProperties}>
      <aside className="sidebar">
        <button className="brand" onClick={() => navigate('home')} data-testid="brand-home"><span className="brand-mark"><Atom size={28} strokeWidth={1.7} /></span><span><strong>آزمایشگاه عناصر</strong><small>کشف عناصر / ۰۱ تا ۳۶</small></span></button>
        <div className="side-label">منوی آزمایشگاه</div>
        <nav className="side-nav" aria-label="منوی اصلی">
          <button className={page === 'home' ? 'active' : ''} onClick={() => navigate('home')} data-testid="nav-home"><FlaskConical size={19} /> نمای کلی</button>
          <button className={page === 'table' ? 'active' : ''} onClick={() => navigate('table')} data-testid="nav-table"><Atom size={19} /> جدول عناصر</button>
          <button className={page === 'guide' ? 'active' : ''} onClick={() => navigate('guide')} data-testid="nav-guide"><BookOpen size={19} /> راهنما و طراحی</button>
        </nav>
        <div className="side-label modes-label">حالت‌های بازی</div>
        <nav className="side-nav" aria-label="حالت‌های بازی">{(['duel','truth','identify','quiz'] as Mode[]).map(m => { const Icon = modeIcons[m]; return <button key={m} className={mode === m ? 'active' : ''} onClick={() => startMode(m)} data-testid={`side-mode-${m}`}><Icon size={19}/>{MODE_NAMES[m]}</button>; })}</nav>
        <div className="sidebar-bottom"><span className="online-dot"/> سیستم آمادهٔ یادگیری <span className="version">نسخهٔ ۱٫۰</span></div>
      </aside>

      <main className="main-area">
        <header className="topbar"><div className="mobile-brand"><span className="brand-mark"><Atom size={22}/></span><strong>آزمایشگاه عناصر</strong></div><div className="topbar-title"><span className="topbar-dot"/> محیط یادگیری فعال <span className="slash">/</span> {page === 'home' ? mode ? MODE_NAMES[mode] : 'داشبورد' : page === 'table' ? 'جدول تناوبی' : 'راهنمای بازی'}</div><div className="top-actions"><span className="top-xp"><Zap size={15} fill="currentColor"/> {format(progress.xp)} امتیاز</span><button className="icon-button" aria-label={sound ? 'قطع صدا' : 'فعال‌کردن صدا'} title={sound ? 'قطع صدا' : 'فعال‌کردن صدا'} onClick={() => setSound(!sound)} data-testid="sound-toggle">{sound ? <Volume2 size={19}/> : <VolumeX size={19}/>}</button></div></header>
        <div className="content">
          {page === 'home' && !mode && <>
            <section className="hero"><div className="hero-noise"/><div className="hero-copy"><div className="eyebrow"><span className="pulse-dot"/> مأموریت: کشف دنیای ماده</div><h1>دنیای عناصر را<br/><em>کشف کن.</em></h1><p>از هیدروژن تا کریپتون؛ با هر پاسخ درست، یک قدم به تسلط بر جدول تناوبی نزدیک‌تر شو.</p><button className="primary-button" onClick={() => startMode('quiz')} data-testid="hero-start">شروع چالش <ChevronLeft size={19}/></button></div><div className="hero-visual" aria-hidden="true"><div className="orbit orbit-outer"/><div className="orbit orbit-middle"/><div className="orbit orbit-inner"/><div className="hero-atom"><span className="atom-number">عنصر / ۰۸</span><strong>O</strong><span>اکسیژن</span></div><div className="orbit-point point-a"/><div className="orbit-point point-b"/><div className="orbit-point point-c"/><span className="hero-coordinate coord-a">۰۱ — ۳۶</span><span className="hero-coordinate coord-b">آزمایشگاه / ۱۴۰۵</span></div><div className="hero-bottom"><span>✧ یادگیری، یک کشف در هر نوبت</span><span>۰۱ / ۰۴</span></div></section>
            <section className="stats-grid" aria-label="آمار پیشرفت"><div className="stat-card"><div className="stat-icon purple"><Trophy size={19}/></div><span>رتبهٔ فعلی</span><strong data-testid="current-rank">{rank.label}</strong><small>{nextRank ? `${format(nextRank.min - progress.xp)} امتیاز تا رتبهٔ بعد` : 'به بالاترین رتبه رسیدی!'}</small></div><div className="stat-card"><div className="stat-icon cyan"><Zap size={19}/></div><span>امتیاز تجربه</span><strong data-testid="xp-display">{format(progress.xp)} <small>XP</small></strong><div className="mini-progress"><i style={{width:`${rankPercent}%`}}/></div></div><div className="stat-card"><div className="stat-icon orange"><Flame size={19}/></div><span>زنجیرهٔ فعلی</span><strong data-testid="streak-display">{format(progress.streak)} <small>پاسخ درست</small></strong><small>بهترین زنجیره: {format(progress.bestStreak)}</small></div><div className="stat-card"><div className="stat-icon green"><Check size={19}/></div><span>پاسخ‌های درست</span><strong data-testid="correct-display">{format(progress.correct)} <small>از {format(progress.total)}</small></strong><small>هر ۵ پاسخ درست = یک ابزار تازه</small></div></section>
            <div className="section-heading"><div><span className="section-kicker">چالش خودت را انتخاب کن</span><h2>حالت‌های بازی</h2><p>روش یادگیری خودت را انتخاب کن.</p></div><span className="section-count">۰۴ حالت متفاوت <span className="count-line"/></span></div>
            <section className="mode-grid">{(['duel','truth','identify','quiz'] as Mode[]).map((m, i) => { const Icon = modeIcons[m]; return <button className={`mode-card mode-${m}`} key={m} onClick={() => startMode(m)} data-testid={`mode-${m}`}><span className="mode-top"><span className="mode-icon"><Icon size={25}/></span><span className="mode-index">۰{i+1} / ۰۴</span></span><span className="mode-body"><strong>{MODE_NAMES[m]}</strong><span>{MODE_DESCRIPTIONS[m]}</span></span><span className="mode-footer">شروع بازی <ChevronLeft size={18}/></span></button>; })}</section>
            <section className="preview-banner"><span className="preview-icon"><Atom size={25}/></span><div><strong>جدول تناوبی، همیشه کنار تو</strong><p>۳۶ عنصر نخست را لمس کن و ویژگی‌هایشان را بشناس.</p></div><button onClick={() => navigate('table')} data-testid="open-table-preview">مشاهدهٔ جدول <ChevronLeft size={18}/></button></section>
          </>}

          {page === 'home' && mode && question && <div ref={questionRef} className="game-view"><button className="back-link" onClick={exitGame} data-testid="exit-game"><ChevronRight size={18}/> بازگشت به داشبورد</button><div className="game-heading"><div><span className="section-kicker">چالش فعال / {MODE_NAMES[mode]}</span><h1>{MODE_NAMES[mode]}</h1><p>{MODE_DESCRIPTIONS[mode]}</p></div><span className="game-mode-icon">{(() => { const Icon = modeIcons[mode]; return <Icon size={27}/>; })()}</span></div>
            <div className="game-layout"><div className="game-primary"><div className={`question-panel ${feedback === 'wrong' ? 'shake wrong-glow' : feedback === 'correct' ? 'success-glow' : ''}`} data-testid="question-panel"><div className="question-top"><span className="question-counter"><span className="small-dot"/> سؤال {format(progress.total + (feedback ? 0 : 1))}</span><span className={`timer ${seconds <= 7 && !feedback ? 'urgent' : ''}`} data-testid="timer"><Clock3 size={17}/> {format(seconds)} ثانیه</span></div><div className="timer-track"><i style={{width:`${Math.min(100,seconds/25*100)}%`}}/></div><div className="question-content"><span className="question-type">{mode === 'duel' ? 'مقایسهٔ عناصر' : mode === 'truth' ? 'واقعیت‌سنجی' : mode === 'identify' ? 'شناسایی عنصر' : 'انتخاب پاسخ درست'}</span><h2 data-testid="question-text">{question.prompt}</h2>{mode === 'duel' && <p className="question-note">دو عنصر را مقایسه کن و گزینهٔ درست را انتخاب کن.</p>}{mode === 'identify' && <div className="clue-tags"><span>گروه {format(question.element.Group)}</span><span>دورهٔ {format(question.element.Period)}</span><span>{question.element.Category}</span></div>}</div>
              {mode === 'duel' && question.focus && <div className="duel-options">{question.focus.map((el, index) => <button key={el.Atomic_Number} disabled={!!feedback} onClick={() => submitAnswer(el.Name)} className={`duel-choice ${feedback && el.Name === question.correct ? 'right-choice' : ''} ${feedback === 'wrong' && el.Name !== question.correct ? 'faded-choice' : ''}`} data-testid={`duel-choice-${index}`}><span className="duel-symbol" style={{color:palette[el.Category]}}>{el.Symbol}</span><strong>{el.Name}</strong><small>عدد اتمی {format(el.Atomic_Number)} · {el.Category}</small><span className="duel-facts">جرم: {format(el.Mass)} u<br/>الکترونگاتیوی: {el.Electronegativity === null ? 'نامشخص' : format(el.Electronegativity)}<br/>ذوب: {format(el.Melting_Point)}° · جوش: {format(el.Boiling_Point)}°</span></button>)}</div>}
              {mode === 'truth' && <div className="truth-options"><button disabled={!!feedback} onClick={() => submitAnswer('درست')} data-testid="truth-yes" className={feedback && question.correct === 'درست' ? 'right-choice' : ''}><Check size={21}/> درست است</button><button disabled={!!feedback} onClick={() => submitAnswer('نادرست')} data-testid="truth-no" className={feedback && question.correct === 'نادرست' ? 'right-choice' : ''}><X size={21}/> نادرست است</button></div>}
              {mode === 'identify' && <form className="identify-form" onSubmit={e => {e.preventDefault(); if(answer.trim()) submitAnswer(answer);}}><label htmlFor="element-answer">نام عنصر را به فارسی بنویس</label><div className="answer-row"><input id="element-answer" type="text" autoComplete="off" spellCheck={false} placeholder="مثلاً: اکسیژن" value={answer} onChange={e => setAnswer(e.target.value)} disabled={!!feedback} data-testid="identify-input"/><button className="primary-button" type="submit" disabled={!!feedback || !answer.trim()} data-testid="identify-submit">ثبت پاسخ <ChevronLeft size={17}/></button></div></form>}
              {mode === 'quiz' && <div className="quiz-options">{question.options.map((option, i) => <button key={option} disabled={!!feedback || hiddenOptions.includes(option)} onClick={() => submitAnswer(option)} data-testid={`quiz-option-${i}`} className={`${hiddenOptions.includes(option) ? 'removed-choice' : ''} ${feedback && option === question.correct ? 'right-choice' : ''}`}><span className="option-letter">{['الف','ب','پ','ت'][i]}</span><span dir="auto">{option}</span><ChevronLeft size={17}/></button>)}</div>}
              {hint && <div className="hint-box" data-testid="hint-text"><Lightbulb size={18}/> {question.hint}</div>}
              {feedback && <div className={`feedback-box ${feedback}`} data-testid="answer-feedback"><div className="feedback-icon">{feedback === 'correct' ? <Check size={25}/> : <X size={25}/>}</div><div><strong>{feedback === 'correct' ? `درست گفتی!  +${format(lastPoints)} امتیاز` : seconds === 0 ? 'زمان تمام شد!' : 'اشتباه شد؛ دوباره تلاش کن!'}</strong><p>{question.detail}</p></div>{feedback === 'correct' && <div className="particles" aria-hidden="true">{Array.from({length:10},(_,i)=><i key={i} style={{'--i':i} as React.CSSProperties}/>)}</div>}</div>}
              <div className="question-bottom"><span><Info size={15}/> {feedback ? 'برای ادامه، سؤال بعدی را بزن.' : 'هر پاسخ درست، تو را به کشف بعدی نزدیک می‌کند.'}</span>{feedback && <button className="primary-button" onClick={nextQuestion} data-testid="next-question">سؤال بعدی <ChevronLeft size={18}/></button>}</div></div></div>
              <aside className="game-aside"><div className={`aside-card ${multiplier > 1 ? 'combo-on' : ''}`}><div className="aside-heading"><span><Flame size={18}/> وضعیت زنجیره</span><span className="live-label">زنده</span></div><div className="streak-figure"><strong data-testid="game-streak">{format(progress.streak)}</strong><span>پاسخ پیاپی</span></div><div className="combo-strip"><span>ضریب کمبو</span><strong data-testid="combo-multiplier">×{format(multiplier)}</strong></div><p className="aside-tip">پاسخ درست بعدی را تا ۱۲ ثانیه بده تا زنجیره ادامه پیدا کند.</p></div><div className="aside-card tools-card"><div className="aside-heading"><span><Sparkles size={18}/> ابزارهای آزمایشگاه</span></div><p className="tools-intro">هر ۵ پاسخ درست، یک ابزار جایزه می‌گیری.</p><button disabled={!!feedback || mode !== 'quiz' || progress.tools.microscope === 0 || hiddenOptions.length > 0} onClick={() => useTool('microscope')} data-testid="tool-microscope"><span className="tool-icon"><Microscope size={19}/></span><span><strong>میکروسکوپ</strong><small>حذف دو گزینهٔ نادرست</small></span><em>{format(progress.tools.microscope)}</em></button><button disabled={!!feedback || progress.tools.time === 0} onClick={() => useTool('time')} data-testid="tool-time"><span className="tool-icon"><Clock3 size={19}/></span><span><strong>تغییر زمان</strong><small>۱۰ ثانیه زمان اضافه</small></span><em>{format(progress.tools.time)}</em></button><button disabled={!!feedback || progress.tools.scanner === 0 || hint} onClick={() => useTool('scanner')} data-testid="tool-scanner"><span className="tool-icon"><ScanSearch size={19}/></span><span><strong>اسکنر</strong><small>نمایش یک راهنمایی</small></span><em>{format(progress.tools.scanner)}</em></button></div></aside></div>
          </div>}

          {page === 'table' && <><div className="page-intro"><div><span className="section-kicker">جدول تعاملی عناصر</span><h1>جدول تناوبی عناصر</h1><p>روی هر خانه بزن تا با ویژگی‌های آن عنصر آشنا شوی. این نسخه ۳۶ عنصر نخست را پوشش می‌دهد.</p></div><span className="intro-badge"><Atom size={18}/> ۳۶ عنصر</span></div><div className="table-card"><div className="table-card-top"><span><span className="small-dot"/> مرور تعاملی عناصر</span><span>دوره‌های ۱ تا ۴</span></div><div className="periodic-scroll"><div className="periodic-grid">{TABLE_POSITIONS.map(pos => { const el = ELEMENT_BY_NUMBER.get(pos.number)!; return <button key={pos.number} style={{gridColumn:pos.column,gridRow:pos.row,'--tile-color':palette[el.Category]} as React.CSSProperties} className={`element-tile ${selected?.Atomic_Number === pos.number ? 'selected' : ''}`} onClick={() => setSelected(el)} data-testid={`element-${pos.number}`} aria-label={`${el.Name}، عدد اتمی ${format(el.Atomic_Number)}`}><span className="tile-number">{format(el.Atomic_Number)}</span><strong>{el.Symbol}</strong><small>{el.Name}</small></button>; })}</div></div><div className="table-legend">{Object.entries(palette).map(([name,color]) => <span key={name}><i style={{background:color}}/>{name}</span>)}</div></div>{selected ? <div className="element-details" style={{'--detail-color':palette[selected.Category]} as React.CSSProperties} data-testid="element-detail"><div className="detail-identity"><div className="detail-symbol"><small>{format(selected.Atomic_Number)}</small><strong>{selected.Symbol}</strong></div><div><span className="section-kicker">شناسهٔ عنصر / {selected.Symbol.toUpperCase()}</span><h2>{selected.Name}</h2><p>{selected.Category} · گروه {format(selected.Group)} · دورهٔ {format(selected.Period)}</p></div><button className="icon-button detail-close" onClick={() => setSelected(null)} aria-label="بستن جزئیات" data-testid="close-element"><X size={18}/></button></div><div className="detail-grid"><div><span>جرم اتمی</span><strong>{format(selected.Mass)} <small>u</small></strong></div><div><span>الکترونگاتیوی</span><strong>{selected.Electronegativity === null ? 'ثبت نشده' : format(selected.Electronegativity)}</strong></div><div><span>نقطهٔ ذوب</span><strong>{format(selected.Melting_Point)} <small>°C</small></strong></div><div><span>نقطهٔ جوش</span><strong>{format(selected.Boiling_Point)} <small>°C</small></strong></div><div className="config-detail"><span>آرایش الکترونی</span><strong dir="ltr">{selected.Electron_Configuration}</strong></div></div></div> : <div className="table-empty"><Maximize2 size={21}/><span>برای دیدن مشخصات، یکی از عناصر جدول را انتخاب کن.</span></div>}</>}

          {page === 'guide' && <Guide onStart={() => startMode('quiz')}/>}
          <footer className="footer"><span>آزمایشگاه عناصر <span className="footer-separator">/</span> ساخته‌شده برای ذهن‌های کنجکاو</span><span>۳۶ عنصر · ۴ بازی · بی‌نهایت کشف</span></footer>
        </div>
      </main>
      <nav className="mobile-nav" aria-label="دسترسی سریع"><button className={page === 'home' && !mode ? 'active' : ''} onClick={() => navigate('home')} data-testid="mobile-home"><FlaskConical size={21}/><span>خانه</span></button><button className={page === 'table' ? 'active' : ''} onClick={() => navigate('table')} data-testid="mobile-table"><Atom size={21}/><span>عناصر</span></button><button className={mode ? 'active' : ''} onClick={() => startMode('quiz')} data-testid="mobile-play"><Zap size={21}/><span>بازی</span></button><button className={page === 'guide' ? 'active' : ''} onClick={() => navigate('guide')} data-testid="mobile-guide"><CircleHelp size={21}/><span>راهنما</span></button></nav>
    </div>
  );
}

function Guide({onStart}:{onStart:()=>void}) {
  return <div className="guide-page"><div className="page-intro"><div><span className="section-kicker">سند طراحی بازی / نسخهٔ ۱</span><h1>راهنمای آزمایشگاه</h1><p>هم راهنمای بازی، هم نقشهٔ طراحی و ساخت آن؛ همه‌چیز یک‌جا.</p></div><BookOpen size={32} className="guide-intro-icon"/></div><div className="guide-grid"><section className="guide-card"><span className="guide-number">۰۱ / چشم‌انداز</span><h2>هدف بازی و چرخهٔ یادگیری</h2><p>«آزمایشگاه عناصر» یک بازی آموزشی کوتاه‌مرحله‌ای برای شناخت ۳۶ عنصر نخست است. بازیکن یک حالت را انتخاب می‌کند، ویژگی عنصر را تحلیل می‌کند، پاسخ می‌دهد و بازخورد فوری می‌گیرد. هر نوبت با پرسش تازه ادامه پیدا می‌کند.</p><div className="guide-flow"><span>انتخاب بازی</span><ChevronLeft size={17}/><span>پاسخ</span><ChevronLeft size={17}/><span>بازخورد</span><ChevronLeft size={17}/><span>پیشرفت</span></div></section><section className="guide-card"><span className="guide-number">۰۲ / حالت‌های بازی</span><h2>چهار مسیر یادگیری</h2><ul><li><strong>دوئل عناصر:</strong> مقایسهٔ ویژگی کمی دو عنصر.</li><li><strong>درست یا نادرست:</strong> تشخیص گزاره‌های واقعی و اشتباه.</li><li><strong>عنصرشناس:</strong> نوشتن نام فارسی عنصر از روی نشانه‌ها.</li><li><strong>آزمون بزرگ:</strong> انتخاب یکی از چهار پاسخ دربارهٔ ساختار و ویژگی‌ها.</li></ul></section><section className="guide-card"><span className="guide-number">۰۳ / پیشرفت و پاداش</span><h2>از کیمیاگر تا افسانه</h2><p>هر پاسخ درست ۲۰ امتیاز پایه دارد. سه پاسخ سریع پیاپی ضریب ×۲، پنج پاسخ ×۳ و هشت پاسخ ×۵ می‌دهد. برای ادامهٔ زنجیره، فاصلهٔ پاسخ‌های درست نباید بیش از ۱۲ ثانیه باشد. پاسخ نادرست زنجیره را صفر می‌کند.</p><div className="rank-list">{RANKS.map(r=><span key={r.label}>{r.label} <small>{format(r.min)} XP</small></span>)}</div></section><section className="guide-card"><span className="guide-number">۰۴ / ابزارها</span><h2>تجهیزات آزمایشگاه</h2><p>هر ۵ پاسخ درست، یک ابزار به‌صورت چرخشی جایزه داده می‌شود. میکروسکوپ دو پاسخ غلط را فقط در آزمون چهارگزینه‌ای حذف می‌کند. تغییر زمان ۱۰ ثانیه اضافه می‌کند و اسکنر یک سرنخ نشان می‌دهد.</p><div className="guide-flow"><span>۵ پاسخ درست</span><ChevronLeft size={17}/><span>دریافت ابزار</span><ChevronLeft size={17}/><span>استفاده در بازی</span></div></section><section className="guide-card"><span className="guide-number">۰۵ / منطق تعامل</span><h2>نقشهٔ کمبو و ابزار</h2><div className="flowchart"><span>شروع پرسش · زمان‌سنج ۲۵ ثانیه</span><span>↓</span><span>استفاده از ابزار؟ ← کاهش موجودی و اجرای اثر</span><span>↓</span><span>پاسخ درست؟</span><div><span>بله ← بررسی فاصلهٔ ۱۲ ثانیه ← ضریب کمبو ← امتیاز و ابزار</span><span>خیر / اتمام زمان ← قطع زنجیره ← نمایش پاسخ</span></div><span>↓</span><span>پرسش بعدی</span></div></section><section className="guide-card"><span className="guide-number">۰۶ / داده و فناوری</span><h2>ساختار فنی</h2><p>رابط با React و TypeScript ساخته شده؛ حرکت‌ها و افکت‌ها با CSS و صدای بازخورد با Web Audio اجرا می‌شوند تا روی گوشی روان بمانند. چیدمان جدول از دادهٔ مستقل عناصر جداست. امتیاز، رتبه و ابزارها فقط روی همین دستگاه ذخیره می‌شوند.</p><p>شِمای داده برای هر عنصر شامل شمارهٔ اتمی، نماد، نام فارسی، جرم، الکترونگاتیوی، نقطهٔ ذوب و جوش، آرایش الکترونی، گروه، دوره و دسته‌بندی است.</p><a className="schema-link" href="/elements.schema.json" target="_blank" rel="noreferrer" data-testid="schema-link">مشاهدهٔ شِمای داده <ChevronLeft size={17}/></a></section></div><div className="guide-cta"><div><strong>آماده‌ای دانشت را محک بزنی؟</strong><p>اولین پرسش آزمایشگاه منتظر توست.</p></div><button className="primary-button" onClick={onStart} data-testid="guide-start">شروع آزمون <ChevronLeft size={18}/></button></div></div>;
}
export default App;
